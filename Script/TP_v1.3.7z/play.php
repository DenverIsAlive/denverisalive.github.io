<?php
// Define id variable
$id = $_GET['id'] ?? null;

if ($id === null) {
    echo '<h1>Error:  id Parameter Missing</h1>';
    exit;
}

// Get Catch-up Segment from Parameter
$catchupRequest = false;
$beginTimestamp = $endTimestamp = null;
if (isset($_GET['begin'], $_GET['end'])) {// Catch Only Work in TiviMate & Ott Navigator
    $catchupRequest = true;
    $beginTimestamp = intval($_GET['begin']);
    $endTimestamp = intval($_GET['end']);
    $beginFormatted = gmdate('Ymd\THis', $beginTimestamp);
    $endFormatted = gmdate('Ymd\THis', $endTimestamp);
}

// Fetch and decode JSON data
$JsonFile = fetchJson('secure/TP.json');
if ($JsonFile === false) {
    echo '<h1>Error fetching Json file</h1>';
    exit;
}

// Decode JSON data
$fetcherData = $JsonFile;

// Function to fetch JSON data
function fetchJson($url) {
    $json = @file_get_contents($url);
    return $json !== false ? json_decode($json, true) : false;
}

// Find the channel data by ID
$channelData = null;
foreach ($fetcherData as $channel) {
    if ($channel['channel_id'] === $id) {
        $channelData = $channel;
        break;
    }
}

if (!$channelData) {
    http_response_code(404);
    exit('<h1>data not found for channel</h1>');
}

if (!isset($channelData['is_catchup_available']) || $channelData['is_catchup_available'] === false) {
    $catchupRequest = false;
}

// Get the current protocol (http or https)
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$base_path = rtrim(dirname($_SERVER['PHP_SELF']), '/');

// Construct the HMAC URL
$hmacUrl = "{$protocol}://{$_SERVER['HTTP_HOST']}" . ($base_path ? $base_path : '') . "/hmac.php?id=" . urlencode($id);

// Fetch the HMAC value
$hmacResponse = @file_get_contents($hmacUrl);
if ($hmacResponse === false) {
    http_response_code(500);
    exit('<h1>Error: Failed to Load HMAC</h1>');
}

// Decode the HMAC response
$hmacData = json_decode($hmacResponse, true);
$hdntlRaw = $hmacData['hmac']['hdntl']['value'] ?? null;
$userAgent = $hmacData['userAgent'] ?? null;

if (!$hdntlRaw) {
    http_response_code(500);
    exit('<h1>Error: hdntl value not found</h1>');
}

// Remove the "?" from the HMAC value
$hmac = ltrim($hdntlRaw, '?');

$manifestUrl = $channelData['channel_url'];
if (strpos($manifestUrl, 'bpaita') === false) {
    header("Location: $manifestUrl");
    exit;
}

// manifest url replace with
$manifestUrl = str_replace("bpaita", "bpaicatchupta", $manifestUrl);
$baseUrl = dirname($manifestUrl);

// Generate time parameters based on conditions
function generateTimeParameters($id, $beginParam = null, $endParam = null) {
    $currentTimestamp = time();
    
    // Check if begin & end are provided in the URL
    if (!empty($beginParam) && !empty($endParam)) {
        return [
            'begin' => $beginParam,
            'end' => $endParam
        ];
    }

    // IDs that require a 14-minute window instead of 30 minutes
    $specialIds = ['24', '78', '503', '123', '175', '727', '64', '251', 
                   '248', '249', '515', '254', '250', '636', '1288', 
                   '257', '675', '810', '694', '1287'];

    // Set time window based on ID
    $beginTimestamp = in_array($id, $specialIds) ? 
                      $currentTimestamp - (14 * 60) :  // 14 minutes ago for special IDs
                      $currentTimestamp - (30 * 60);  // 30 minutes ago for others

    $endTimestamp = $currentTimestamp + (4 * 60 * 60); // 4 hours ahead

    return [
        'begin' => gmdate('Ymd\THis', $beginTimestamp),
        'end' => gmdate('Ymd\THis', $endTimestamp)
    ];
}

// Generate time parameters
$timeParams = generateTimeParameters($id, $beginParam, $endParam);

$manifestUrl .= "?begin=" . $timeParams['begin'] . "&end=" . $timeParams['end'] . "&" . $hmac;
if ($catchupRequest) {
    $manifestUrl .= '&begin=' . $beginFormatted . '&end=' . $endFormatted;
}

// Fetch Function
function fetchContent($url, $want_response_header = false) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => $want_response_header,
        CURLOPT_NOBODY => $want_response_header,
        CURLOPT_HTTPHEADER => [
            'User-Agent: Shraddha/5.0',
            'Accept: */*', 
    'Connection: keep-alive', 
    'Origin: https://watch.tataplay.com',
    'Referrer: https://watch.tataplay.com/'
        ]
    ]);
    
    $response = curl_exec($ch);
    $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $responseCode === 200 ? $response : null;
}

$originalMpdContent = fetchContent($manifestUrl);
if (!$originalMpdContent) {
    http_response_code(500);die("failed to fetch mpd");
}
$mpdContent = $originalMpdContent;

// extract pssh from mpdContent
function extractWidevinePssh(string $content, string $baseUrl, ?int $catchupRequest): ?array {
    if (($xml = @simplexml_load_string($content)) === false) return null;
    foreach ($xml->Period->AdaptationSet as $set) {
        if ((string)$set['contentType'] === 'audio') {
            foreach ($set->Representation as $rep) {
                $template = $rep->SegmentTemplate ?? null;
                if ($template) {
                    $startNumber = $catchupRequest ? (int)($template['startNumber'] ?? 0) : (int)($template['startNumber'] ?? 0) + (int)($template->SegmentTimeline->S['r'] ?? 0);
                    $media = str_replace(['$RepresentationID$', '$Number$'], [(string)$rep['id'], $startNumber], $template['media']);
                    $url = "$baseUrl/dash/$media";
                    if (($content = fetchContent($url)) != false) {
                        $hexContent = bin2hex($content);
                        return extractKid($hexContent);
                    }
                }
            }
        }
    }
    return null;
}

// extract default kid from mpdContent
function extractKid($hexContent) {
    $psshMarker = "70737368";
    $psshOffset = strpos($hexContent, $psshMarker);
    
    if ($psshOffset !== false) {
        $headerSizeHex = substr($hexContent, $psshOffset - 8, 8);
        $headerSize = hexdec($headerSizeHex);
        $psshHex = substr($hexContent, $psshOffset - 8, $headerSize * 2);
        $kidHex = substr($psshHex, 68, 32);
        $newPsshHex = "000000327073736800000000edef8ba979d64acea3c827dcd51d21ed000000121210" . $kidHex;
        $pssh = base64_encode(hex2bin($newPsshHex));
        $kid = substr($kidHex, 0, 8) . "-" . substr($kidHex, 8, 4) . "-" . substr($kidHex, 12, 4) . "-" . substr($kidHex, 16, 4) . "-" . substr($kidHex, 20);
        
        return ['pssh' => $pssh, 'kid' => $kid];
    }
    return null;
}

// mpdContent inside modification
$mpdContent = preg_replace_callback('/<SegmentTemplate\s+.*?>/', function ($matches) use ($hmac) {
    $cleaned = preg_replace('/(\$Number\$\.m4s|\$RepresentationID\$\.dash)[^"]*/', '$1', $matches[0]);
    return str_replace(['$Number$.m4s', '$RepresentationID$.dash'],['$Number$.m4s?' . $hmac, '$RepresentationID$.dash?' . $hmac], $cleaned);
}, $mpdContent);

$mpdContent = preg_replace('/<BaseURL>.*<\/BaseURL>/', "<BaseURL>$baseUrl/dash/</BaseURL>", $mpdContent);

if (strpos($mpdContent, 'pssh') === false && strpos($mpdContent, 'cenc:default_KID') === false) {

    $widevinePssh = extractWidevinePssh($mpdContent, $baseUrl, $catchupRequest);
    if ($widevinePssh === null) {
        http_response_code(500); die("Unable to extract Pssh.");
    }
    $mpdContent = preg_replace('/<BaseURL>.*<\/BaseURL>/', "<BaseURL>$baseUrl/dash/</BaseURL>", $mpdContent);

    $newContent = "<!-- Common Encryption -->\n      <ContentProtection schemeIdUri=\"urn:mpeg:dash:mp4protection:2011\" value=\"cenc\" cenc:default_KID=\"{$widevinePssh['kid']}\"/>";
 
    $mpdContent = str_replace('<ContentProtection value="cenc" schemeIdUri="urn:mpeg:dash:mp4protection:2011"/>',$newContent,$mpdContent);
 
    $pattern = '/<ContentProtection\s+schemeIdUri="(urn:[^"]+)"\s+value="Widevine"\/>/';

    $mpdContent = preg_replace_callback($pattern, function ($matches) use ($widevinePssh) {
        return "<!--Widevine-->\n      <ContentProtection schemeIdUri=\"{$matches[1]}\" value=\"Widevine\">\n        <cenc:pssh>{$widevinePssh['pssh']}</cenc:pssh>\n      </ContentProtection>";
    }, $mpdContent);
  
    $mpdContent = preg_replace('/xmlns="urn:mpeg:dash:schema:mpd:2011"/', '$0 xmlns:cenc="urn:mpe:cenc:2013"', $mpdContent);
}

header('Content-Type: application/dash+xml');
header('Content-Disposition: attachment; filename="manifest_@Denver1769.mpd"');
echo $mpdContent;
exit;
?>