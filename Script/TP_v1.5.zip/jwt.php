<?php
header("Content-Type: application/json");

// Get `id` parameter from the query string
$id = $_GET['id'] ?? null;

if ($id === null) {
    echo json_encode(['error' => 'Missing "id" parameter'], JSON_PRETTY_PRINT);
    exit;
}

// Determine protocol (HTTP or HTTPS)
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $base_path = rtrim(dirname($_SERVER['PHP_SELF']), '/');


// Construct the full URL to widevine.php
$widevineUrl = "{$protocol}://{$_SERVER['HTTP_HOST']}{$base_path}/widevine.php?id=" . urlencode($id);

// Fetch widevineUrl JSON data
$wvResponse = @file_get_contents($widevineUrl);

if ($wvResponse === false) {
    echo json_encode(['error' => 'Failed to fetch widevine data'], JSON_PRETTY_PRINT);
    exit;
}

// Decode the widevine JSON response
$wvData = json_decode($wvResponse, true);

// Validate required fields
if (!isset($wvData['widevine'], $wvData['jwt'], $wvData['expire'])) {
    echo json_encode(['error' => 'Invalid response from jwt.php'], JSON_PRETTY_PRINT);
    exit;
}

// Check expiry time
$expireString = $wvData['expire']; // Format: "DD/MM/YYYY HH:MM PM/AM"
$expireTime = DateTime::createFromFormat('d/m/Y h:i A', $expireString);

$currentTime = new DateTime('now', new DateTimeZone('Asia/Kolkata'));

if ($currentTime > $expireTime) {
    echo json_encode([
        'error' => 'Token expired',
        'expired_at' => $expireString,
        'current_time' => $currentTime->format('d/m/Y h:i A')
    ], JSON_PRETTY_PRINT);
    exit;
}

$licenceUrlRaw = $wvData['widevine'];
$jwtRaw = $wvData['jwt'];

// Construct final license URL
$licenceURL = $licenceUrlRaw . '&ls_session=' . urlencode($jwtRaw);

// Redirect to the constructed URL
header("Location: $licenceURL", true, 307);
exit();
?>